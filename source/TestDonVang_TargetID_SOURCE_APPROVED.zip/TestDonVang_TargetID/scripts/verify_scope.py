"""Static regression checks for scope of the target-ID-only build."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
controller = (root / 'generated_runtime/controller.cpp').read_text(encoding='utf-8')
bridge = (root / 'generated_runtime/bridge.cpp').read_text(encoding='utf-8')
cmake = (root / 'CMakeLists.txt').read_text(encoding='utf-8')
saved_click = (root / 'src/saved_hidden_click.h').read_text(encoding='utf-8')
regression = (root / 'src/saved_hidden_click_test.cpp').read_text(encoding='utf-8')

timing_header=(root / 'src/target_loop_logic.h').read_text(encoding='utf-8')
checks = {
    'all five delays initially zero': all(f'{name} = 0;' in timing_header for name in ('delayTargetMs','delayClick1Ms','delayTradeMs','delayClick2Ms','delayCycleMs')),
    'exact 10.6 1e6 coordinate scale': 'fixed_slot_sell_logic::NormalizeClientCoordinate' in saved_click and 'fixed_slot_sell_logic::kCoordinateScale' in saved_click and 'scaledX*10000' not in saved_click and '480546' in regression and '473186' in regression,
    'existing account discovery and per-PID bridge': 'FindClients()' in controller and 'SetWindowsHookExW(' in controller,
    'account selection retained': 'LVS_EX_CHECKBOXES' in controller and 'IDC_START_CHECKED' in controller and 'IDC_STOP_CHECKED' in controller,
    'individual nearby scanner and checkbox': 'ScanNearbyPlayers' in controller and 'IDC_NEARBY_LIST' in controller and 'SetTargetFromCheck' in controller,
    'per-account target storage': 'AccountSection(int roleID)' in controller and 'TargetRoleID' in controller,
    'per-account workers and state': 'std::thread worker' in controller and 'target_loop::State loop' in controller,
    'manual click 1 and click 2 stored': all(s in controller for s in ('Click1X','Click1Y','Click2X','Click2Y','VK_F8','WM_HOTKEY','RegisterHotKey')), 
    'v10.6-like hidden click dispatch': all(x in controller for x in ('DispatchSavedHiddenClick','Command::ClickInternalPointRawTest','2200','saved_hidden_click::Normalize')),
    'arm capture and independent test buttons': all(x in controller for x in ('ArmClick(1)','ArmClick(2)','TEST CLICK 1','TEST CLICK 2','PollCaptureHotkeys()','CaptureArmedClick(armedClick_)')),
    'raw command has no SafeForAction / raycast gate': ('case Command::ClickInternalPointRawTest:' in bridge and 'InvokeInternalPointClick(normalizedX, normalizedY, detail, cap, true)' in bridge and 'if (!InvokeInternalPointClick(normalizedX, normalizedY, detail, cap, true)) return false;' in bridge and 'SafeForAction(' not in bridge.split('bool ClickInternalPointRawTest(')[1].split('bool InvokeInternalPointDrag(')[0]),
    'target-trade-click loop actions': all('Command::'+cmd in controller for cmd in ('SelectTargetByRoleID','ClickTravelSemantic','ClickInternalPointRawTest')) and 'Command::ClickTargetFace' not in controller,
    'per-account repeat and delay saved': all(key in controller for key in ('RepeatCycles','DelayTargetMs','DelayClick1Ms','DelayTradeMs','DelayClick2Ms','DelayCycleMs')),
    'log tab and logging': 'L"LOG"' in controller and 'PushLog(' in controller,
    'ON/OFF LOG persisted with tab kept': all(term in controller for term in ('IDC_LOG_TOGGLE','ToggleLog()','LogEnabled','g_logEnabled.load()', 'g_logEnabled.store(on)')),
    'unchanged width and 15-visible-rows scan': '1060,755,nullptr,nullptr,instance,&app)' in controller and '14,230,1012,345,IDC_NEARBY_LIST' in controller and '14,22,1012,110,IDC_CLIENT_LIST' in controller,
    'compact controls relocated below scan': all(term in controller for term in ('14,608,IDC_REPEAT','360,608,IDC_DELAY_TARGET','706,631,IDC_DELAY_CYCLE','14,654,300,19,IDC_SAVE_TIMING')),  
    'old workflow GUI removed': all('L"'+label+'"' not in controller for label in ('DỒN ĐỒ','TELEGRAM','DEVELOPER','AUTO TRAIN')),
    'legacy main/con worker removed': 'MAIN/CON' not in controller,
    'Windows build and portable tests': 'add_executable(ThanLongItemConsolidator WIN32' in cmake and 'target_loop_logic_tests' in cmake,
    'no obsolete modules in build': all(token not in cmake for token in ('route_logic_test.cpp','auto_loot_logic_test.cpp','telegram_logic_tests')),
}
for name, okay in checks.items():
    print(('PASS' if okay else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit('Scope verification FAILED')
print(f'Scope verification PASSED: {len(checks)} checks')
