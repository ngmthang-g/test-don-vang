# Publishes extracted sources ONLY to the dedicated build branch; never touches main.
# Requires git and permission to push to ngmthang-g/test-don-vang.
$ErrorActionPreference = 'Stop'
$branch = 'exe/target-id-loop'
$repo = 'https://github.com/ngmthang-g/test-don-vang.git'
$source = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$temp = Join-Path $env:TEMP ('target-id-upload-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $temp | Out-Null
$destination = Join-Path $temp 'repo'
try {
    git clone --branch $branch --single-branch $repo $destination
    if ($LASTEXITCODE -ne 0) { throw 'Không clone được nhánh build.' }
    # The dedicated branch initially has README only. For subsequent runs we must
    # delete previous tracked source files except .git to make the clean complete.
    Get-ChildItem -LiteralPath $destination -Force | Where-Object { $_.Name -ne '.git' } |
        Remove-Item -Recurse -Force
    Get-ChildItem -LiteralPath $source -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $destination -Recurse -Force
    }
    git -C $destination add -A
    if ($LASTEXITCODE -ne 0) { throw 'git add thất bại.' }
    git -C $destination diff --cached --quiet
    if ($LASTEXITCODE -eq 0) {
        Write-Host 'Không có thay đổi mới trên nhánh.'
    } else {
        git -C $destination commit -m 'feat: per-account target ID loop, nearby scan and log-only UI'
        if ($LASTEXITCODE -ne 0) { throw 'git commit thất bại (cần cấu hình git user.name/email).' }
        git -C $destination push origin $branch
        if ($LASTEXITCODE -ne 0) { throw 'Không push được nhánh build.' }
        Write-Host "Đã push nhánh $branch. Mở GitHub Actions để xem build Windows."
    }
} finally {
    if (Test-Path $temp) { Remove-Item $temp -Recurse -Force }
}
