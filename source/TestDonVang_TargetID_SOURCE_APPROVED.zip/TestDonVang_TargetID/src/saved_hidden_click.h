#pragma once
#include <cstdint>
namespace saved_hidden_click {
// Matches 10.6 ClickPoint's x/y/baseW/baseH model.
// Older versions stored 0..9999 coords, migrated with baseW=baseH=10000.
struct Point {
    int x=-1, y=-1, baseW=0, baseH=0;
    bool Valid() const { return x>=0 && y>=0 && baseW>0 && baseH>0 && x<baseW && y<baseH; }
};
inline bool Normalize(const Point& saved, int clientW,int clientH,int& outX,int& outY) {
    outX=outY=-1;
    if(!saved.Valid()||clientW<=0||clientH<=0)return false;
    // MulDiv rounded pixel scaling, then the original 10.6 0..9999 normalization.
    const auto scaledX=(static_cast<std::int64_t>(saved.x)*clientW+saved.baseW/2)/saved.baseW;
    const auto scaledY=(static_cast<std::int64_t>(saved.y)*clientH+saved.baseH/2)/saved.baseH;
    if(scaledX<0||scaledX>=clientW||scaledY<0||scaledY>=clientH)return false;
    outX=static_cast<int>(scaledX*10000/clientW);
    outY=static_cast<int>(scaledY*10000/clientH);
    return outX>=0&&outX<10000&&outY>=0&&outY<10000;
}
} // namespace saved_hidden_click
