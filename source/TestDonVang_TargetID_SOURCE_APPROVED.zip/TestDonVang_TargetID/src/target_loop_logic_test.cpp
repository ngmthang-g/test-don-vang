#include "target_loop_logic.h"
#include <cassert>
int main() {
    target_loop::State a, b;
    a.targetRoleID = b.targetRoleID = 2345; // shared targets are allowed
    for (int i = 0; i < 24; ++i) {
        a.Finish((i % 3) == 0); // even repeated errors keep stepping
        if (i < 8) b.Finish(true);
    }
    assert(a.cycles == 6 && a.errors == 16);
    assert(b.cycles == 2 && b.errors == 0);
    assert(a.step == target_loop::Step::Target && b.step == target_loop::Step::Target);
    b.targetRoleID = 9876;
    assert(a.targetRoleID == 2345 && b.targetRoleID == 9876);
}
