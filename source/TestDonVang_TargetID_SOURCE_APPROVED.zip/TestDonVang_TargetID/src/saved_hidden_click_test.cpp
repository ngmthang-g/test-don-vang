#include "saved_hidden_click.h"
#include <cassert>
int main() {
    using namespace saved_hidden_click;
    int x,y;
    assert(Normalize({250,125,1000,500},1000,500,x,y)&&x==2500&&y==2500);
    assert(Normalize({250,125,1000,500},2000,1000,x,y)&&x==2500&&y==2500);
    assert(Normalize({2500,2500,10000,10000},1000,500,x,y)&&x==2500&&y==2500);
    assert(!Normalize({-1,-1,0,0},1000,500,x,y));
    assert(!Normalize({1000,0,1000,500},1000,500,x,y));
    assert(!Normalize({12,30,1000,500},0,500,x,y));
    assert(Normalize({999,499,1000,500},1000,500,x,y)&&x==9990&&y==9980);
}
