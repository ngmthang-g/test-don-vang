#pragma once
#include <cstdint>
namespace target_loop {
// One state machine per game account. Failure never locks or aborts the cycle.
enum class Step : std::uint8_t { Target, Face, Trade, Click2 };
inline Step Next(Step step) {
    switch (step) {
        case Step::Target: return Step::Face;
        case Step::Face: return Step::Trade;
        case Step::Trade: return Step::Click2;
        case Step::Click2: return Step::Target;
    }
    return Step::Target;
}
struct State {
    std::int32_t targetRoleID = 0;
    Step step = Step::Target;
    std::uint64_t cycles = 0;
    std::uint64_t errors = 0;
    void Finish(bool ok) {
        if (!ok) ++errors;
        if (step == Step::Click2) ++cycles;
        step = Next(step);
    }
    void ResetStep() { step = Step::Target; }
};
} // namespace target_loop
