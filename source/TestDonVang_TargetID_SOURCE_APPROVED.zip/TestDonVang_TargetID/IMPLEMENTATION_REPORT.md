# Báo cáo triển khai trên cơ sở source ZIP

1. Giữ nguyên `FindClients` / `BridgeClient` từ Test Đơn Vàng, Win32 ListView nhiều ACC, tick ACC riêng, Start/Stop, tabs AUTO TARGET ID + LOG.
2. Thêm `ScanNearbyPlayers` Bridge từ cơ chế ObjectManager.sprites AutoBuff 1.3.1 (signature guard, check GRole class/RoleID, không lọc Peace), 1 tick RoleID/ACC và lưu INI theo RoleID chủ ACC.
3. Thêm `ClickTargetFace` dựa trên SelectedTarget + active UI geometry; không xác định được portrait: fail-closed, giữ vòng tiếp tục.
4. Kế thừa lệnh `SelectTargetByRoleID`, `ClickTravelSemantic(Trade)`, `ClickInternalPoint` và hook/shared memory.
5. Worker độc lập theo PID, mutex từng Bridge, trạng thái + lỗi + chu kỳ riêng. Có thể chung RoleID đích.
6. Loại bỏ các tab/điều phối/module và test chỉ dành cho train, dồn đồ, lọc trang bị, các chuỗi giao dịch cũ, Telegram, Dev. Một số helpers legacy của Bridge còn nằm trong `bridge.cpp` nhưng không có UI/đường gọi sau clean; **chưa hoàn thành dead-code pruning toàn bộ Bridge**.
7. Kiểm chứng: test logic độc lập chạy trên Linux; build Windows/MSVC và kiểm thử game thực tế chưa có trong môi trường tạo bản này.

## Điều kiện còn phải xác nhận trong game
- Quét GRole đọc được tên và ID, bao gồm người không Peace.
- Click mặt target đúng UI từng bản game (Canvas / tên UI target).
- Giao dịch và click2 thực hiện chính xác, mục tiêu rời vùng không khiến target đổi.
- 2+ game client target trùng ID không ảnh hưởng nhau, chạy liên tục.

## Trạng thái bàn giao
- Đã tạo source trong ZIP để phát hành vào nhánh riêng.
- Nhánh `exe/target-id-loop` trên GitHub đã tạo, **source trong ZIP chưa tự động push lên đó**.
- Có `scripts/publish-to-branch.ps1` để đẩy lên nhánh bằng máy có Git được cấp quyền.
- Không có EXE mới đã được build hay xác nhận chạy game thực tế.
