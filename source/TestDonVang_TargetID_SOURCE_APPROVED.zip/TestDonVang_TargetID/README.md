# Test Đơn Vàng — Auto Target ID (phát triển từ bản 10.6)

- Vẫn dùng trình quản lý nhiều ACC Windows, tự nhận client đang nạp `GameAssembly.dll`, Bridge theo từng PID, cấu hình riêng từng nhân vật, hai lệnh **BẮT ĐẦU/DỪNG ACC TICK** và tab **LOG**.
- Trong **AUTO TARGET ID**, chọn ACC rồi **QUÉT NGƯỜI XUNG QUANH**. Danh sách checkbox nhận `RoleID` và tên từ `ObjectManager.sprites` (chuyển từ Auto Buff v1.3.1, bỏ lọc Peace). Mỗi ACC tick **đúng một** RoleID; nhiều ACC có thể tick chung một RoleID. Chọn RoleID được lưu theo RoleID của chính ACC vào `%LOCALAPPDATA%\ThanLongCleanRoute\target_id_accounts.ini`, kể cả khi nhân vật được tick rời tầm quét.
- Click 1: người dùng tự đặt điểm click trong game bằng **F8** theo từng ACC. Bridge click tọa độ đã lưu, không tìm portrait hay tự suy ra tọa độ.
- Click 2: chọn ACC, đưa chuột vào vị trí mong muốn ở cửa sổ game rồi nhấn **F8** để lưu tọa độ cho ACC đó.
- Trình tự worker của mỗi ACC: `SelectTargetByRoleID → ClickInternalPoint(Click1) → ClickTravelSemantic(Trade) → ClickInternalPoint(Click2) → lặp`. Lỗi/timeout của từng bước không chặn vòng kế, và không gửi chồng yêu cầu Bridge cho cùng PID.
- Giữ nguyên license launcher/API gate từ Test Đơn Vàng gốc. Các workflow train, lọc vũ khí, dồn đồ, MAIN/CON, Telegram, developer và tab giới thiệu đã được bỏ khỏi GUI và build.

## Build

Yêu cầu Windows x64 + Visual Studio 2022 + CMake 3.24+.

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
```

Đặt `TestDonVang_TargetID.exe` và `ThanLongCleanRouteBridge.dll` **cạnh nhau**. GitHub Actions job `build-target-id.yml` xuất cả hai file.

## Thận trọng

Chưa có kiểm thử thực tế trên game Windows. Scan RVA dựa trên chữ ký phiên bản đã kiểm tra trong source Auto Buff 1.3.1; game khác bản sẽ từ chối scan thay vì đọc sai. Tọa độ F8 được gán thủ công; cần kiểm tra trực tiếp để xác nhận click đúng UI. **Không coi một build pass là đã được nghiệm thu in-game.**

## Đưa source lên nhánh GitHub riêng để lấy EXE

Do môi trường tạo bản nguồn không thể kết nối trực tiếp GitHub để đẩy ZIP lên nhánh,
source đã được đóng gói riêng. Giải nén ZIP; trên máy có Git và quyền ghi repository,
mở PowerShell tại thư mục `TestDonVang_TargetID` rồi chạy:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\publish-to-branch.ps1
```

Script **chỉ** cập nhật `exe/target-id-loop`, không động vào `main`.
Sau đó mở [Actions](https://github.com/ngmthang-g/test-don-vang/actions) để lấy artifact
chứa `TestDonVang_TargetID.exe` và `ThanLongCleanRouteBridge.dll` nếu build pass.
Chưa chạy được Windows CI hoặc kiểm tra trên game thật trong môi trường phát triển này.

## Điều khiển Click 1 / Click 2, số chuỗi và delay riêng từng ACC

- Mở ACC, bấm **QUÉT NGƯỜI XUNG QUANH**, tick một RoleID. Nhiều ACC được tick cùng RoleID.
- **Click 1**: đặt con trỏ chuột vào tọa độ *mặt nhân vật* mong muốn trong cửa sổ game của ACC đang chọn, rồi nhấn **F8**. Không tự dò vị trí mặt.
- **Click 2**: đặt chuột tại điểm thứ hai trong game, nhấn **F8**. Cả hai điểm là tọa độ tương đối theo client window (0..9999), lưu riêng theo RoleID ACC.
- **Số chuỗi**: 0 = vô hạn; N = chạy đủ N chuỗi rồi tự dừng.
- Delay sau Target, Click 1, Callback Giao dịch, Click 2 và **delay giữa chuỗi** có thể đặt riêng, đơn vị ms (0..60000). Delay của mỗi bước áp dụng cả khi bước đó báo lỗi; sau Click 2 cộng thêm delay giữa chuỗi.
- Bấm **LƯU REPEAT / DELAY CHO ACC** để lưu. Các thay đổi không ảnh hưởng ACC khác. Lưu ở `target_id_accounts.ini` theo RoleID của ACC.
- Nếu chưa gán tọa độ click, bước click báo lỗi trong tab LOG rồi chuyển sang bước kế.


### Compact UI and log toggle (v3)

- The main Win32 window remains **1060px wide**; its initial height is **475px** (formerly 935px). Buttons, list views, tab area, edit controls and vertical spacing have been compressed accordingly. The font remains 13px for readability instead of becoming illegibly small.
- **LOG: ON / LOG: OFF** is visible on the top row from either tab. OFF suspends new log recording but keeps already displayed messages, the LOG tab, clear/export actions, and all ACC operations. ON resumes recording.
- The log switch is global and persists in the existing `target_id_accounts.ini` under `[Interface] LogEnabled=1/0`. It does not stop workers or change target/click/repeat/delay settings.


## v4: Sửa CLICK ẨN 1/2 theo nguồn 10.6
- Nhấn **CHỌN CLICK 1 → F8** trên tool để ARM (chỉ chờ, không lấy tọa ngay). Đưa chuột đến vị trí mặt trong game của ACC đang chọn, nhấn F8; tọa độ pixel và kích thước client lúc gán được lưu riêng theo RoleID. Tương tự **CHỌN CLICK 2 → F8**.
- Dùng RegisterHotKey F8 + WM_HOTKEY đúng bản 10.6; nếu F8 đã bị ứng dụng khác đăng ký, dự phòng poll 30 ms và ghi cảnh báo LOG.
- Nhấn **TEST CLICK 1/2** để test click ẩn của đúng ACC ngay, độc lập Auto Target, đồng thời xem tab LOG và cột trạng thái. Để LOG ON khi chẩn đoán.
- Tại mọi vòng/TEST, tọa được scale theo kích thước client hiện tại và normalize 10000, sau đó gọi `Command::ClickInternalPoint` với `rawMacro=0`, timeout 2200ms như đường `CoordinatorInternalPointAction` 10.6 (InputSync TryClickUI → EndUIDrag trong Bridge).
- Dữ liệu F8 phiên bản trước (`Click1X/Y`,`Click2X/Y` normalized) được đọc theo chuẩn cũ nếu chưa có `Click1W/H`, `Click2W/H` mới.
- Nếu log báo raycast UI hoặc chuyển map, Bridge đã từ chối thao tác; không đồng nhất lệnh PASS với việc game chắc chắn đã đổi UI. Chưa xác minh trên game thật.


## Lưu ý xác minh click ẩn
Cả Click 1 và Click 2 đều gán bằng F8 nhưng phải bấm CHỌN CLICK tương ứng trước. TEST CLICK chỉ xác nhận Bridge Invoke/InputSync, không xác nhận game đã mở đúng UI; kiểm tra tận mắt màn hình game. Log có tọa pixel, kích thước client và normalized để đối chiếu.

## Click ẩn RAW không điều kiện (v6)
- Hai điểm CLICK 1 và CLICK 2 đều gán bằng **F8**. Đầu tiên bấm **CHỌN CLICK 1** hoặc **CHỌN CLICK 2** rồi đưa chuột vào chính client game của ACC đó, nhấn F8 để lưu x/y và kích thước client. Mỗi điểm được lưu độc lập theo ACC.
- Bước click (cả khi TEST lẫn khi chạy chuỗi) gọi `ClickInternalPointRawTest` (opcode 26 đã có sẵn từ 10.6), thực thi RAW `InputSyncManager.TryClickUI → EndUIDrag`. Không nhận diện target portrait, không tìm UI tree, không yêu cầu `SafeForAction`, không dùng raycast/_uiDragging làm điều kiện tiến bước.
- Lệnh được gửi sau bước target/callback bất kể hai bước đó thất bại, miễn là ACC được chọn và đã gán tọa độ hợp lệ. Tọa chưa gán hoặc cửa sổ game không còn tồn tại là lỗi dữ liệu/transport, không thể thực hiện click.
- Bridge báo thành công **chỉ xác nhận lệnh InputSync đã được gọi**, không xác nhận giao diện game thực sự phản ứng.
- Chức năng callback Giao dịch vẫn tìm dòng Giao dịch; yêu cầu “không nhận dạng UI” chỉ áp dụng cho hai nút click ẩn, không thay đổi callback.
